cd /opt/traccar/bin
sudo ./startDaemon.sh

