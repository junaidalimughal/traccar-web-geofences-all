Ext.define('Traccar.view.dialog.AddUserController', {
    extend: 'Traccar.view.dialog.BaseEditController',
    alias: 'controller.adduser',

    onFileChange: function (fileField) {
        var reader;

        if (fileField.fileInputEl.dom.files.length > 0) {
            /*var userModel = Ext.create('Traccar.model.User', {
                email: 'abc@gmail.com', 
                password:'xyz'
            });

            userModel.save();   
            alert("user created.");
            */
            var file = fileField.fileInputEl.dom.files[0].name;
            console.log("file name is --> " + file);
            console.log("Extension is --> " );
            if (file.split('.').pop().toLowerCase() === 'xls'.toLowerCase()) {
                console.log("Reading the file...");
                reader = new FileReader();
                reader.onload = function (event) {
                    var data = event.target.result;

                    var workbook = XLSX.read(data, {
                        type: 'binary'
                    });

                    workbook.SheetNames.forEach(function(sheetName) {
                        var xl_row_object = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName])
                        var json_row_object = JSON.stringify(xl_row_object);
                        var users = JSON.parse(json_row_object);
                        
                        users.forEach(function(user) {
                            var userModel = Ext.create('Traccar.model.User', {
                                name: user['name'],
                                email: user['email'],
                                password: user['password']
                            });
                            
                            userModel.save();
                        });
                    })
                };

                reader.onerror = function (event) {
                    Traccar.app.showError(event.target.error);
                };
                console.log("Starting reading file.");
                reader.readAsBinaryString(fileField.fileInputEl.dom.files[0]);
                console.log("reading file finished.");
    
            }       
            
            
        }
    }
});
